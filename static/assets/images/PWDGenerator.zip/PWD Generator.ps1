﻿#Path to where the word files are located If you are running this as a script you could use something like $script:MyInvocation.MyCommand.Path
$FilePath = Split-path $script:MyInvocation.MyCommand.Path


Function Get-RandomPWD {
    [CmdletBinding()]
    param (
        [switch]$RandomizeOrder
    )
    #I generate 10 password, because sometimes the passwords generated fall in NSFW category
    For ($i=1;$i -le 10;$i++) {
	
        
        $FullPWD = @()	
        #First I pick the length of the first word between 2 and 6 characters
	    $value1 = Get-Random -Minimum 2 -Maximum 6
         #Getting a random  number
	    $Value2 = Get-Random -Minimum 1 -Maximum 99
        # Figure out how many characters I have to the second word
	    $value3 = 10 - $value1 - ($Value2.ToString().Length)

      
	    #Actually getting the first and second random word from the txt file containing the wordlist
	    $PWD1 = Get-Content "$FilePath\uk$($value1).txt" | Get-Random
	    $PWD2 = Get-Content "$FilePath\uk$($value3).txt" | Get-Random
        #To make sure I have at least 1 uppercase letter, I select a random letter from the second word
	    [STRING]$PWD2RandomChar = $PWD2.ToCharArray() | Get-Random		
        #I now do a simple replace of the randomly selected character to an uppercase letter.
	    $PWD3 = $PWD2 -replace ($PWD2RandomChar, $PWD2RandomChar.ToUpper())
        $FullPWD += $PWD1,$Value2,$PWD3	
        
            If ($RandomizeOrder) {
                $r = new-object Random
                #Randomize the order of 3 parts of the password
	            $PassWD += "$(($FullPWD  |  Get-Random -Count $FullPWD.Count) -join '')`n"
	        }
            Else {
                #Output the password as Word Number Word
                $PassWD += "$PWD1$value2$PWD3`n"
            }    
   
	}
	
	 $passwd

}


Get-RandomPWD # -RandomizeOrder



#Get-Content C:\Scripts\Wordlist.txt | where {$_.length -eq 7} | Get-Random -Count 100 | out-file 'C:\scripts\AP\PWD Generator\Publish\uk7.txt'